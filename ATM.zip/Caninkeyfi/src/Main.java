import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan= new Scanner(System.in);
        int balance=2000;
        while(true){
            System.out.println("\t\tWRITE YOUR PROCESS NUMBER");
            System.out.println("1-)Balance inquiry\n2-)Withdrawal\n3-)Lodgement\nFor exit:q");
            String choose=scan.nextLine();
            if(choose.equals("1")){
                System.out.println("Your balance is "+balance);
            } else if (choose.equals("2")) {
                System.out.println("Enter the amount you want to withdraw money.\nYour balance is "+balance);
                int withdrawal=scan.nextInt();
                scan.nextLine();
                if(withdrawal<=balance){
                    balance-=withdrawal;
                    System.out.println("***CASH OUT***\t"+withdrawal+"\tYour balance is "+balance);
                }
                else{
                    System.out.println("Your balance is insufficient.\tYour balance is "+balance);
                }
            } else if (choose.equals("3")) {
                System.out.println("Enter the amount you want to lodgement");
                int lodgement=scan.nextInt();
                scan.nextLine();
                balance+=lodgement;
                System.out.println("***CASH IN***\tYour balance is "+balance);
            } else if (choose.equals("q")) {
                System.out.println("Finish!!");
                break;
            } else{
                System.out.println("Invalid Input!");
            }
        }
}
}