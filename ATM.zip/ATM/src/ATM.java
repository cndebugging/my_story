import java.util.Scanner;

public class ATM {
    public void run(Account user1){
        Login login=new Login();
        Scanner scan=new Scanner(System.in);
        int attemp=3;
        while (true){
            if(Login.Check(user1)){
                break;
            }
            else{
                System.out.println("Incorrect Attemp");
                attemp-=1;
            }
            if(attemp==0){
                System.out.println("***BLOCK***");
                return;
            }
        }

        while(true){
            String choose="1.Balance\n"+"2.Cash in\n"+"3.Cash out\n"+"For exit use: q";
            System.out.println(choose);
            System.out.println("Choose your process:\t");
            String process=scan.nextLine();
            if(process.equals("q")){
                break;
            }
            else if(process.equals("1")){
                System.out.println("Your balance is "+user1.getBalance());
            }
            else if(process.equals("2")){
                System.out.println("Cash in : ");
                int cash_in= scan.nextInt();;
                scan.nextLine();
                user1.Cash_in(cash_in);
            }
            else if(process.equals("3")){
                System.out.println("Cash out : ");
                int cash_out= scan.nextInt();;
                scan.nextLine();
                user1.Cash_out(cash_out);
            }
            else{
                System.out.println("Invalid attemp");
            }
        }

    }
}
