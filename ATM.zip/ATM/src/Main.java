public class Main {
    public static void main(String[] args) {
        Account user1= new Account("user","asdf",1000);
        ATM atm=new ATM();
        atm.run(user1);
        System.out.println("Good bye!");
    }
}