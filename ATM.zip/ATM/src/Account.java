public class Account {
    private String user_name;
    private String password;
    private int Balance;

    public Account(String user_name, String password, int balance) {
        this.user_name = user_name;
        this.password = password;
        this.Balance = balance;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getBalance() {
        return Balance;
    }

    public void setBalance(int balance) {
        Balance = balance;
    }
    public void Cash_in(int money){
        Balance+=money;
        System.out.println("New balanace: "+Balance);
    }
    public void Cash_out(int money){
        if(money>Balance){
            System.out.println("Balance is not enough!\nYour balance is "+Balance);
        }
        else{
            Balance-=money;
            System.out.println("New balance is "+Balance);
        }
    }
}
