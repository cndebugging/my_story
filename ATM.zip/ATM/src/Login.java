import java.util.Scanner;

public class Login {

    public static boolean Check (Account user1){
        Scanner scan=new Scanner(System.in);
        System.out.println("User name: ");
        String user_name= scan.nextLine();
        System.out.println("Password: ");
        String password=scan.nextLine();
        if(user1.getUser_name().equals(user_name) && user1.getPassword().equals(password)){
            System.out.println("Succesful login!!");
            return true;
        }
        else{
            return false;
        }
    }


}
