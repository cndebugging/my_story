import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan= new Scanner(System.in);
        String user_name=("Can");
        String user_password=("12345");
        int number=3;
        while (true) {
            System.out.print("User name: ");
            String name_input=scan.nextLine();
            if (user_name.equals(name_input)) {
                System.out.print("Password: ");
                String password = scan.nextLine();
                if (user_password.equals(password)) {
                    System.out.println("Hello " + user_name);
                } else {
                    System.out.println("Incorrect Password");
                    number -= 1;
                }
            } else {
                System.out.println("User is not found!");
                number -= 1;
            }
            if (number == 0) {
                System.out.println("***BLOCK***");
                break;
            }
        }
    }
}