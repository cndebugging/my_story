import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan= new Scanner(System.in);
        System.out.print("Welcome to the interest calculator.\nMoney:");
        int money= scan.nextInt();
        System.out.print("How many year: ");
        int year= scan.nextInt();
        float new_balance=money;
        for(int i=0;i<year; i++){
            new_balance=new_balance+(new_balance*6/100);
            System.out.println("At the end of the "+(i+1)+" year: "+new_balance);
        }

        System.out.println(new_balance);
    }
}