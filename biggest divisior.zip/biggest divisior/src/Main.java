import java.util.Scanner;

public class Main {
    public static  int the_biggest_divisior(int a, int b){
        int big=0;
        int biggest_divisior=0;
        if(a>b){
            big=a;
        }else{
            big=b;
        }
        for(int i=1;i<big; i++){
            if( a%i==0 && b%i==0 ){
                biggest_divisior=i;
            }
        }
        System.out.println("The biggest divisior is "+biggest_divisior);
        return biggest_divisior;
    }
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.print("Number_1: ");
        int number1=scan.nextInt();
        System.out.print("Number_2: ");
        int number2=scan.nextInt();
        the_biggest_divisior(number1,number2);

        System.out.println("Hello world!");
    }
}