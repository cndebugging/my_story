import java.util.Scanner;

public class IT extends Members{
    private String language;
    public IT(String name, String surname, int ıd, String language) {
        super(name, surname, ıd);
        this.language=language;
    }
    public void task(String doing){
        System.out.println(getName()+"is doing"+doing);
    }

    @Override
    public void show_information() {
        super.show_information();
        System.out.println("IT member know "+ language);
    }
}
