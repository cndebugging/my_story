public class Members {
    private String name;
    private String surname;
    private int ıd;

    public Members(String name, String surname, int ıd) {
        this.name = name;
        this.surname = surname;
        this.ıd = ıd;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public int getId() {
        return ıd;
    }

    public void setId(int ıd) {
        this.ıd = ıd;
    }
    public void show_information(){
        System.out.println("Name: "+name);
        System.out.println("Surame: "+surname);
        System.out.println("Id: "+ıd);
    }
}
