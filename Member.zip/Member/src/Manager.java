public class Manager extends Members{
    private int responsible;
    public Manager(String name, String surname, int ıd,int responsible) {
        super(name, surname, ıd);
        this.responsible=responsible;
    }

    @Override
    public void show_information() {
        super.show_information();
        System.out.println("Administrator responsible for "+responsible+" people");
    }
}
