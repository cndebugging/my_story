import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        while(true){
            System.out.println("Process: \n1.IT\n2.Manager\nWrite q for exit");
            String process= scan.nextLine();
            if(process.equals("1")){
                IT member1=new IT("can","uysal",12345,"Python,Java");
                System.out.println("1-Show information\n2-Task\n3-Exit");
                while (true){
                    int choose= scan.nextInt();
                    if(choose==1){
                        member1.show_information();
                    } else if (choose==2) {
                        System.out.print("Doing: ");
                        String tasks=scan.nextLine();
                        member1.task(tasks);
                    } else if (choose==3) {
                        break;
                    }else{
                        System.out.println("Invalid Input");
                    }
                }

            } else if (process.equals("2")) {

            Manager manager=new Manager("Elon","Musk",1925,200);
                while (true){
                    System.out.println("1-Show information\n2-Exit");
                    int choose_2= scan.nextInt();
                    if(choose_2==1){
                        manager.show_information();
                    } else if (choose_2==2) {
                        break;
                    }else{
                        System.out.println("Invalid Input");
                    }

                }


            } else if (process.equals("q")) {
                break;
            }else {
                System.out.println("***Invalid Input***");
            }
        }
    }
}