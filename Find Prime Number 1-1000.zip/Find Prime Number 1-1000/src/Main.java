
public class Main {
    public  static boolean find_prime(int number){
        for (int i =2; i<number;i++){
            if(number%i==0){
                return false;
            }
        }
        return true;
    }
    public static void main(String[] args) {
        for(int i=2;i<1001;i++){
            if(find_prime(i)){
                System.out.println(i+" is prime number.");
            }
        }
    }
}